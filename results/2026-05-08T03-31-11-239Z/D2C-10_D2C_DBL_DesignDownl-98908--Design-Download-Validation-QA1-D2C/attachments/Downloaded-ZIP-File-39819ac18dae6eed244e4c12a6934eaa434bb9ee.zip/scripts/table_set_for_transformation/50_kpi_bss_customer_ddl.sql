prompt 50_kpi_bss_customer_ddl

SET ECHO ON SQLTERMINATOR ON

-- KPI_BSS_CUSTOMER_DDL / KPI_BSS_CUSTOMER
BEGIN
  FOR I IN (SELECT * FROM USER_OBJECTS WHERE OBJECT_NAME=upper('KPI_BSS_CUSTOMER'))
  LOOP
    EXECUTE IMMEDIATE 'DROP '||I.OBJECT_TYPE||' '||I.OBJECT_NAME;
  END LOOP;
END;
/

-- KPI_BSS_CUSTOMER_DDL / KPI_BSS_CUSTOMER
CREATE TABLE KPI_BSS_CUSTOMER  PCTFREE 0 NOLOGGING AS
select 
	domain as DOMAIN,
	be_entity as BE_ENTITY,
	be_entity_desc as BE_ENTITY_DESC,
	cast (null as number) as LEGACY_COUNT,
	(select count(*) from SDB_PH1_PERSONAL_DETAILS) as SDB_COUNT,
	(select count(*) from IDB_PH1_CIM_CUSTOMER) as IDB_COUNT,
	(select count(*) from CT_IDB_PH1_CIM_CUSTOMER) as VALID_IDB_COUNT,
	cast (null as number) as TARGET_COUNT FROM
(
select 'CIM' as domain, 
       'Customer' as be_entity,
       'Customer' as be_entity_desc
from dual
);
