prompt 50_kpi_bss_individual_ddl

SET ECHO ON SQLTERMINATOR ON

-- KPI_BSS_INDIVIDUAL_DDL / KPI_BSS_INDIVIDUAL
BEGIN
  FOR I IN (SELECT * FROM USER_OBJECTS WHERE OBJECT_NAME=upper('KPI_BSS_INDIVIDUAL'))
  LOOP
    EXECUTE IMMEDIATE 'DROP '||I.OBJECT_TYPE||' '||I.OBJECT_NAME;
  END LOOP;
END;
/

-- KPI_BSS_INDIVIDUAL_DDL / KPI_BSS_INDIVIDUAL
CREATE TABLE KPI_BSS_INDIVIDUAL  PCTFREE 0 NOLOGGING AS
select 
	domain as DOMAIN,
	be_entity as BE_ENTITY,
	be_entity_desc as BE_ENTITY_DESC,
	cast (null as number) as LEGACY_COUNT,
	(select count(*) from SDB_PH1_PERSONAL_DETAILS) as SDB_COUNT,
	(select count(*) from IDB_PH1_CIM_INDIVIDUAL) as IDB_COUNT,
	(SELECT count(*) FROM CT_IDB_PH1_CIM_INDIVIDUAL) as VALID_IDB_COUNT,
	cast (null as number) as TARGET_COUNT FROM
(
select 'CIM' as domain, 
       'Individual' as be_entity,
       'Individual' as be_entity_desc
from dual
);
