prompt 00_meta_d2c_version_dml

SET ECHO OFF SQLTERMINATOR OFF

-- META_D2C_VERSION_DML / META_D2C_VERSION
INSERT /*+ APPEND */ INTO META_D2C_VERSION (ID, VERSION, CREATED_BY, CREATED_WHEN, FILE_NAME)
(
SELECT 'd2c_example_IDB_ora_Srini.xlsx', '0.2', 'Liza', '12-04-24', 'input/d2c_example_IDB_ora_Srini-1779173137/d2c_example_IDB_ora_Srini.xlsx' FROM DUAL
)
/
COMMIT
/
